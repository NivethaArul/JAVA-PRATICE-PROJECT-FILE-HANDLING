package phase1;
import java.io.*;
public class FileHandling {
	void Filewrite(){
		String data="The filewritter is created";
		try{
			FileWriter output=new FileWriter("data.text");
			output.write(data);
			output.close();
			System.out.println("The file is written to be successfully");
		}
		catch(IOException e){
			System.out.println("File Write error");
		}
	}
void Fileread(){
	char [] data=new char[28];
	try{
		FileReader input=new FileReader("data.text");
		input.read(data);
	    System.out.println("The data is received from a file.");
	    System.out.println(data);
	   input.close();
	}
	catch(IOException e){
		System.out.println("File Read error");
	}
	}
void Append(){
	String data="This data is appended";
	try{
	FileWriter input=new FileWriter("data",true);
	input.write(data);
	input.close();
	System.out.println(" The data is appended");
	}
	catch(IOException e){
		System.out.println("File Write error");
	}
	
}
	public static void main(String[] args) {
	    FileHandling f=new FileHandling();
	    f.Filewrite();
	    f.Fileread();
	    f.Append();
	    
	}

}



